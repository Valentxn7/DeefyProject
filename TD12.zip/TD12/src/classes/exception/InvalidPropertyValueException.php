<?php

namespace iutnc\deefy\exception;

class InvalidPropertyValueException extends \Exception
{
}