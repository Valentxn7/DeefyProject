<?php

namespace iutnc\deefy\exception;

class InvalidPropertyNameException extends \Exception
{
}